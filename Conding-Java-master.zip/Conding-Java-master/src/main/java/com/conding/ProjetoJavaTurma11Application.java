package com.conding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoJavaTurma11Application {

    public static void main(String[] args) {
        SpringApplication.run(ProjetoJavaTurma11Application.class, args);
    }

}
