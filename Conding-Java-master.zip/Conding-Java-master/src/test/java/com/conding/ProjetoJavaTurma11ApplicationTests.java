package com.conding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoJavaTurma11ApplicationTests {

    @Test
    void contextLoads() {
    }

}
